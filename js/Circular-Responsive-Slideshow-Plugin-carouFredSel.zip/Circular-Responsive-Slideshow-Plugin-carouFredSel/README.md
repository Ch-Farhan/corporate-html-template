carouFredSel
============

A circular, responsive carousel plugin built using the jQuery. See http://caroufredsel.dev7studios.com